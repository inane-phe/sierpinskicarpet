# sierpinski-carpet
sierpinski-carpet

![Screenshot](https://github.com/jurvo/sierpinski-carpet/blob/master/docs/screen.PNG)