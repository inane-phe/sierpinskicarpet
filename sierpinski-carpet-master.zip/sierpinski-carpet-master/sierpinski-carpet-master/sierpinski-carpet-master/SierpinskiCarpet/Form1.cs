﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SierpinskiCarpet
{
	struct PointS
	{
		public short X;
		public short Y;

		public PointS(short x, short y)
		{
			X = x;
			Y = y;
		}
	}

	struct SizeS
	{
		public short Width;
		public short Height;

		public SizeS(short width, short height)
		{
			Width = width;
			Height = height;
		}
	}

	struct SierpinskiCarpet
	{
		public SierpinskiCarpet[] underlying;
		public SizeS Size;
		public PointS TopLeft;

		public SierpinskiCarpet(PointS topLeft, short width, int layer, int maxLayer)
		{
			Size = new SizeS(width, width);
			TopLeft = topLeft;
			if (layer < maxLayer)
			{
				short w = (short)(width / 3);
				underlying = new SierpinskiCarpet[9];
				underlying[0] = new SierpinskiCarpet(topLeft, w, layer + 1, maxLayer);
				underlying[1] = new SierpinskiCarpet(new PointS((short)(topLeft.X + w), topLeft.Y), w, layer + 1, maxLayer);
				underlying[2] = new SierpinskiCarpet(new PointS((short)(topLeft.X + w + w), topLeft.Y), w, layer + 1, maxLayer);

				underlying[3] = new SierpinskiCarpet(new PointS(topLeft.X, (short)(topLeft.Y + w)), w, layer + 1, maxLayer);
				underlying[4] = new SierpinskiCarpet(new PointS((short)(topLeft.X + w), (short)(topLeft.Y + w)), w, layer + 1, maxLayer);
				underlying[5] = new SierpinskiCarpet(new PointS((short)(topLeft.X + w + w), (short)(topLeft.Y + w)), w, layer + 1, maxLayer);

                underlying[6] = new SierpinskiCarpet(new PointS(topLeft.X, (short)(topLeft.Y + w + w)), w, layer + 1, maxLayer);
                underlying[7] = new SierpinskiCarpet(new PointS((short)(topLeft.X + w), (short)(topLeft.Y + w + w)), w, layer + 1, maxLayer);
                underlying[8] = new SierpinskiCarpet(new PointS((short)(topLeft.X + w + w), (short)(topLeft.Y + w + w)), w, layer + 1, maxLayer);
            }
            else
            {
                underlying = new SierpinskiCarpet[0];
            }
		}
	}

	public partial class Form1 : Form
	{
		SierpinskiCarpet m;
        private int fractalDepth = 7; // 預設分形次數
        private Color currentColor = Color.Black; // 預設顏色
		public Form1()
		{
            InitializeComponent();
            ClientSize = new Size(900, 800);
            currentColor = Color.White; // 設定顏色為白色
            m = new SierpinskiCarpet(new PointS(0, 0), (short)ClientSize.Width, 0, 7);
            
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			DrawSponge(m, e.Graphics);
		}
        private void DrawSponge()
        {
            Bitmap bmp = new Bitmap(ClientSize.Width, ClientSize.Height);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.White); // 清空畫布，確保背景是白色
                DrawSponge(m, g);
            }

            pictureBox1.Image = bmp;
        }
		private void DrawSponge(SierpinskiCarpet m, Graphics g)
		{
            if (m.underlying.Length > 0)
            {
                var x = m.underlying[4];
                g.FillRectangle(new SolidBrush(currentColor), new Rectangle(x.TopLeft.X-100, x.TopLeft.Y-100, x.Size.Width, x.Size.Height));
                for (int i = 0; i < m.underlying.Length; i++)
                {
                    if (i != 4)
                        DrawSponge(m.underlying[i], g);
                }
            }
		}

        private void button1_Click(object sender, EventArgs e)
        {
            m = new SierpinskiCarpet(new PointS(0, 0), (short)ClientSize.Width, 0, fractalDepth);
            currentColor = Color.Black;
            DrawSponge(); // 重新繪製視窗
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                currentColor = colorDialog.Color;
                Refresh(); // 重新繪製視窗
            }
        }
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label1.Text = "N = " + trackBar1.Value.ToString();
            fractalDepth = trackBar1.Value;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {

        }

        
	}
}